﻿namespace Person
{
    using System;
    class Child : Person
    {
        private int age;

        public Child(string name, int age) : base(name, age)
        {
            this.Age = age;
        }

        public int Age
        {
            get => this.age;
            set
            {
                if (value>15 && value<0)
                {
                    throw new ArgumentException("A child cannot be more 15 years old");
                }
                this.age = value;
            }
        }
    }
}
