﻿namespace Farm
{
    using System;
    public abstract class Animal
    {
        public void Eat()
        {
            Console.WriteLine("eating...");
        }
    }
}
