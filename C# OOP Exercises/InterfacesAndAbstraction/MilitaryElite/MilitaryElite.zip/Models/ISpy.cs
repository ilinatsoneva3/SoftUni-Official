﻿namespace MilitaryElite.Models
{
    public interface ISpy : ISoldier
    {
        int CodeNumber { get; }
    }
}
