﻿namespace MilitaryElite.Models
{
    public interface IPrivate : ISoldier
    {
        decimal Salary { get; }
    }
}
