﻿namespace AnimalFarm.Models
{
    public static class Exceptions
    {
        public static string NameInvalidException = "Name cannot be empty.";
        public static string AgeInvalidException = "Age should be between 0 and 15.";
    }
}
