﻿namespace P01_RawData
{    
    class RawData
    {
        static void Main(string[] args)
        {
            var runner = new Runner();
            runner.Start();
        }
    }
}
