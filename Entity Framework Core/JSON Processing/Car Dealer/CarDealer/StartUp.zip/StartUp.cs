﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.DTO;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        public const string Path = "./../../../Datasets/Results";

        public static void Main(string[] args)
        {                      
            var context = new CarDealerContext();
            // context.Database.EnsureDeleted();
            // context.Database.EnsureCreated();

            //var inputJson = File.ReadAllText("../../../Datasets/sales.json");

            if (!Directory.Exists(Path))
            {
                Directory.CreateDirectory(Path);
            }

            var result = GetOrderedCustomers(context);
            File.WriteAllText(Path + "/ordered-customers.json", result);
            
            
        }

        public static string GetOrderedCustomers(CarDealerContext context)
        {
            var customers = context
                .Customers
                .OrderBy(c => c.BirthDate)
                .ThenBy(c => c.IsYoungDriver)
                .Select(c => new
                {
                    c.Name,
                    Birthdate = c.BirthDate.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture),
                    c.IsYoungDriver
                })
                .ToList();

            var result = JsonConvert.SerializeObject(customers, Formatting.Indented);

            return result;
        }

        public static string ImportSales(CarDealerContext context, string inputJson)
        {
            var sales = JsonConvert.DeserializeObject<List<Sale>>(inputJson);

            context.Sales.AddRange(sales);
            context.SaveChanges();

            return $"Successfully imported {sales.Count}.";
        }

        public static string ImportCustomers(CarDealerContext context, string inputJson)
        {
            var customers = JsonConvert.DeserializeObject<List<Customer>>(inputJson);

            context.Customers.AddRange(customers);

            context.SaveChanges();

            return $"Successfully imported {customers.Count}.";
        }

        public static string ImportCars(CarDealerContext context, string inputJson)
        {
           
            var carsDTO = JsonConvert.DeserializeObject <List<CarDTO>>(inputJson);

            var cars = new List<Car>();
            var partCar = new List<PartCar>();

            foreach (var carDTO in carsDTO)
            {
                var car = new Car()
                {
                    Make = carDTO.Make,
                    Model = carDTO.Model,
                    TravelledDistance = carDTO.TravelledDistance
                };
                cars.Add(car);

                foreach (var carPartId in carDTO.PartsId.Distinct())
                {
                    var carPart = new PartCar()
                    {                       
                        PartId = carPartId,
                        Car = car
                    };

                    partCar.Add(carPart);
                }
            }

            context.Cars.AddRange(cars);

            context.PartCars.AddRange(partCar);
            context.SaveChanges();

            return $"Successfully imported {cars.Count}.";
        }

        public static string ImportParts(CarDealerContext context, string inputJson)
        {
            var parts = JsonConvert.DeserializeObject<List<Part>>(inputJson) ;
            var supplierIds = context.Suppliers
                .Select(x => x.Id)
                .ToList();

            var count = 0;
            foreach (var part in parts)
            {
                if (supplierIds.Contains(part.SupplierId))
                {
                    context.Add(part);
                    count++;
                }
            }

            context.SaveChanges();

            return $"Successfully imported {count}.";
        }

        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            var suppliers = JsonConvert.DeserializeObject<List<Supplier>>(inputJson);

            context.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count}.";
        }
    }
}