﻿namespace P03_SalesDatabase.Data
{
    internal static class Configuration
    {
        internal static string Connection = "Server=DESKTOP-URSLOO9\\SQLEXPRESS;Database=StoreDatabase;Integrated Security=True;";
    }
}
