﻿namespace P03_SalesDatabase.Data.IOManagement.Contracts
{
    public interface IReader
    {
        string Read();
    }
}
