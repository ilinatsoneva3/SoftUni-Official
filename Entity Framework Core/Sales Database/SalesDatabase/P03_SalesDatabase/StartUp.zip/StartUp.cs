﻿namespace P03_SalesDatabase
{
    using P03_SalesDatabase.Data;
    using P03_SalesDatabase.Data.IOManagement;
    using P03_SalesDatabase.Data.Seeding;
    using P03_SalesDatabase.Data.Seeding.Contracts;
    using System;
    using System.Collections.Generic;

    public class StartUp
    {
        static void Main(string[] args)
        {
           // var context = new SalesContext();
           // var random = new Random();
           // var writer = new ConsoleWriter();
           //
           // var seeders = new List<ISeeder>();
           // seeders.Add(new ProductSeeder(context, random, writer));
           // seeders.Add(new StoreSeeder(context, writer));
           //
           // foreach (var seeder in seeders)
           // {
           //     seeder.Seed();
           // }
        }
    }
}
