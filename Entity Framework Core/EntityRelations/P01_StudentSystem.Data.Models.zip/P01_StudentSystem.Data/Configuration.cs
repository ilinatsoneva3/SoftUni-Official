﻿namespace P01_StudentSystem.Data
{
    internal class Configuration
    {
        internal static string Connection 
            = "Server=DESKTOP-URSLOO9\\SQLEXPRESS;Database=StudentSystem;Integrated Security=True;";
    }
}
