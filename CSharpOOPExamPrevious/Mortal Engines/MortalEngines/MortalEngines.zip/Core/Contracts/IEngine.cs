﻿namespace MortalEngines.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}