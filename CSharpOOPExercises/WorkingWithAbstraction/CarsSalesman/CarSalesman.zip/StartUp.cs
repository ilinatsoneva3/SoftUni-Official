﻿namespace CarsSalesman
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var runner = new Runner();
            runner.Start();
        }
    }
}
