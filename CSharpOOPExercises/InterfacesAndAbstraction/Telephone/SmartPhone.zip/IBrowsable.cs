﻿namespace Telephone
{
    public interface IBrowsable
    {
        string Browse(string URL);
    }
}
