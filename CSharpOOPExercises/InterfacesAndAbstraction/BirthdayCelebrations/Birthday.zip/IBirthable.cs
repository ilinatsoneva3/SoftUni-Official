﻿namespace BirthdayCelebrations
{
    using System;

    public interface IBirthable
    {
        string Name { get; }
        string BirthDate { get; }
    }
}
