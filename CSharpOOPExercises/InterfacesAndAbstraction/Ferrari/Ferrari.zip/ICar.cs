﻿namespace Ferrari
{
    public interface ICar
    {
        string Model { get; } 
    }
}
