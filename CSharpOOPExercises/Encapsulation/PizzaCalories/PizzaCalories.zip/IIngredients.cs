﻿namespace PizzaCalories
{
    public interface IIngredients
    {
        double TotalCalories { get; }
    }
}
