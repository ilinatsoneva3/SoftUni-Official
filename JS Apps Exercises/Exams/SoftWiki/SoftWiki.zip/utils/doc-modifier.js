export default function(doc) {
  return { ...doc.data(), id: doc.id };
}
