import user from "./user.js";
import articles from "./articles.js";
import home from "./home.js";

export default {
  user,
  articles,
  home,
};
