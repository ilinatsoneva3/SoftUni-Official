const firebaseConfig = {
  apiKey: "AIzaSyAQ3RfZkx5ruAR18bbXqMnE713B4CdPtOs",
  authDomain: "jaappsexam.firebaseapp.com",
  databaseURL: "https://jaappsexam.firebaseio.com",
  projectId: "jaappsexam",
  storageBucket: "jaappsexam.appspot.com",
  messagingSenderId: "2924817090",
  appId: "1:2924817090:web:2703b638795da1763b695b",
  measurementId: "G-D1FE9SE431"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
